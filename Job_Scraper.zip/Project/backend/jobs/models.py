from djongo import models

class Job(models.Model):
    title = models.CharField(max_length=255)
    salary = models.CharField(max_length=100)
    location = models.CharField(max_length=255)
    description = models.TextField()

    def __str__(self):
        return self.title
