from django.shortcuts import render
from pymongo import MongoClient

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017/")  # Update with your MongoDB connection
db = client["job_portal"]  # Database name
collection = db["jobs"]  # Collection name

def job_list(request):
    jobs = list(collection.find())  # Fetch jobs from MongoDB
    return render(request, 'jobs/job_list.html', {'jobs': jobs})
