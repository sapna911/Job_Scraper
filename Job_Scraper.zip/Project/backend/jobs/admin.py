from django.contrib import admin
from .models import Job

@admin.register(Job)
class JobAdmin(admin.ModelAdmin):
    list_display = ('title', 'salary', 'location')  # Show these fields in the admin panel
    # search_fields = ('title', 'location')  # Enable search by title or location
