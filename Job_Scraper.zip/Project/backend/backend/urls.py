from django.contrib import admin
from django.urls import path, include
from jobs.views import job_list  # Import job_list view

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('jobs.urls')),
      path('', job_list, name='job_list')
  # Include jobs app URLs
]
