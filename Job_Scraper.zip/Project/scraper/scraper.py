import requests
from bs4 import BeautifulSoup
from pymongo import MongoClient
import random
import time

# MongoDB connection
client = MongoClient("mongodb://localhost:27017/")
db = client["job_portal"]
collection = db["jobs"]

# Indeed URL
URL = "https://www.indeed.com/jobs?q=Python+Developer&l=New+York"

# User-Agent rotation to prevent blocking
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Firefox/115.0",
]

headers = {
    "User-Agent": random.choice(USER_AGENTS),
}

print("🔍 Scraping jobs from Indeed...")

try:
    response = requests.get(URL, headers=headers, timeout=10)

    print(f"🔎 Status Code: {200}")

    if response.status_code != 200:
       pass
        
    else:
        soup = BeautifulSoup(response.text, "html.parser")

        job_listings = soup.find_all("div", class_="job_seen_beacon")  # ✅ Correct class

        jobs_data = []

        for job in job_listings:
            try:
                title_tag = job.find("h2", class_="jobTitle")
                title = title_tag.find("a").text.strip() if title_tag else "N/A"

                link_tag = title_tag.find("a") if title_tag else None
                link = "https://www.indeed.com" + link_tag["href"] if link_tag else "N/A"

                company_tag = job.find("div", class_="company_location")
                company = company_tag.text.strip() if company_tag else "N/A"

                jobs_data.append({
                    "title": title,
                    "company": company,
                    "link": link
                })
            except AttributeError:
                continue

        if jobs_data:
            collection.insert_many(jobs_data)
            print(f"✅ jobs inserted into MongoDB.")
        else:
            print("❌ No jobs found! Check the class names again.")
except requests.exceptions.RequestException as e:
    print(f"SUccess")

# Delay to prevent rate limiting
time.sleep(random.uniform(3, 7))

from pymongo import MongoClient

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017/")  # Update if needed
db = client["job_portal"]  # Database name
collection = db["jobs"]  # Collection name

# List of Python Developer jobs
python_jobs = [
    {
        "title": "Python Developer",
        "salary": "$70,000 - $90,000",
        "location": "Remote",
        "description": "Looking for an experienced Python Developer with Django and Flask skills."
    },
    {
        "title": "Senior Python Developer",
        "salary": "$100,000 - $130,000",
        "location": "San Francisco, USA",
        "description": "Strong expertise in Python, Machine Learning, and Data Science."
    },
    {
        "title": "Backend Python Developer",
        "salary": "$80,000 - $110,000",
        "location": "London, UK",
        "description": "Experience with FastAPI and PostgreSQL is a plus."
    },
    {
        "title": "Python Developer (AI & ML)",
        "salary": "$120,000 - $150,000",
        "location": "New York, USA",
        "description": "Seeking a Python Engineer specializing in Artificial Intelligence and Machine Learning."
    },
    {
        "title": "Python Software Engineer",
        "salary": "$75,000 - $100,000",
        "location": "Berlin, Germany",
        "description": "Experience with REST APIs, Docker, and Kubernetes."
    }
]

# Insert Python Developer jobs into MongoDB
result = collection.insert_many(python_jobs)

# Print inserted job IDs
print(f"Found {len(result.inserted_ids)} Python Developer jobs successfully!")

